#ifndef WEB_ROUTES_H
#define WEB_ROUTES_H

#include <ESP8266WebServer.h>

void register_web_routes(ESP8266WebServer &server);

#endif
